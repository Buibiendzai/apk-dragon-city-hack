# particles.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/Bien-Lor/pen/oNVgMRY](https://codepen.io/Bien-Lor/pen/oNVgMRY).

particles.js - A lightweight JavaScript library for creating particles (canvas)

- http://vincentgarreau.com/particles.js/
- https://github.com/VincentGarreau/particles.js/